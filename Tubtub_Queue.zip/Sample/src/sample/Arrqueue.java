package sample;

public class Arrqueue {
    public static void main(String[] args){
    ArrayQueue arrque = new ArrayQueue(10);
    
    arrque.enqueue(2);
    arrque.enqueue(4);
    arrque.enqueue(6);
    arrque.enqueue(8);
    arrque.enqueue(10);
    arrque.enqueue(12);
    arrque.enqueue(14);
    arrque.enqueue(16);
    arrque.enqueue(18);
    arrque.enqueue(20);
    
    arrque.showQueue();
    System.out.println("PeekRear: " + arrque.peekRear());
 
}
}
